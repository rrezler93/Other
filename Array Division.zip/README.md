Project created for ResDiary Coding Challenge (2023)

Two codes (Python and Javascript) with function groupArrayElements.
Function divides array (arr) into (N) sub-arrays, then return array with sub-arrays inside.

Description from the ResDiary:
  Given an array of length >= 0, and a positive integer N, return the contents of the array divided into N equally sized
  arrays.
  Where the size of the original array cannot be divided equally by N, the final part should have a length equal to the
  remainder.

Please read the "Radoslaw Rezler - GroupArrayElements.docx" attached to the repository for more information.
