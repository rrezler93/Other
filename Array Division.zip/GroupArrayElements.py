# Author:           Radoslaw Rezler
# Date:             20.07.2023
# Project name:     Array Division
# Version:          1.0

# Function groupArrayElements divides array (arr) into (N) sub-arrays
def groupArrayElements(arr, N):
    remainder = len(arr) % N            # check for remainder and save it
    subarray_length = len(arr) // N     # subarray length (if there is no remainder)
    if remainder > 0:                   # add 1 to subarray length (if there is remainder)
        subarray_length += 1

    result = []                         # final array container
    start_index = 0                     # starting index

    for i in range(N):                                                  # loop through N sub-arrays (i)
        result.append(arr[start_index:start_index + subarray_length])   # create sub-array and copy elements
        start_index += subarray_length                                  # set new starting index for each sub-array

    return result                                                       # return as array with N sub-arrays

# Test
print(groupArrayElements([1,2,3,4,5],3))
