// Author:           Radoslaw Rezler
// Date:             20.07.2023
// Project name:     Array Division
// Version:          1.0

// Function groupArrayElements divides array (arr) into (N) sub-arrays:
function groupArrayElements(arr, N) {
  let remainder = arr.length % N;                      // check for remainder and save it
  let subarrayLength = Math.floor(arr.length / N);     // subarray length (if there is no remainder)
  if (remainder > 0) {                                 // add 1 to subarray length (if there is a remainder)
    subarrayLength += 1;
  }

  let result = [];                        // final array container
  let startIndex = 0;                     // starting index

  for (let i = 0; i < N; i++) {                                          // loop through N sub-arrays (i)
    result.push(arr.slice(startIndex, startIndex + subarrayLength));     // create sub-array and copy elements
    startIndex += subarrayLength;                                        // set a new starting index for each sub-array
  }

  return result;                                                         // return as an array with N sub-arrays
}

// Test:
console.log(groupArrayElements([1,2,3,4,5], 3));
